Developer: Sungmin Kang

Game Title: The Balancest Game

Description: The Balancest Game is the 2D platformer game. Move your character, Get some food, and back to your house. Make sure, balance your time(life) and eating foods. Some food will reduce, or increase your time. Watch out the ramp! Your character does not move what you expected!
Hold the Wall! You can hold the wall when you keep your arrow buttons to the matched direction. When the time changes, charater size changes, too. Finally, don't forget that excessive voracity and abstinence can cause death!

Key: 
	left arrow: move left
	right arrow: move right
	space bar: jump

How to Play: 
	Go right until you come back to your home.
	Contact to two different types of food, which make your time reducing, or increasing. 
	When the time changes, charater size changes, too.
	You can hold the wall when you keep your arrow buttons to the matched direction.
	Watch out the ramp. Ramp makes character slightly fly.
	When the time reach the certain point (too high, or too low), game will be ended.


References:

Music - 
Leafre,Murueng,Elinia OST by MapleStory from Nexon Corporation(https://maplestory.nexon.com/Media/Music#a)

Free Casual SoundFX Pack by Tim Beek from the Unity asset Score
(https://assetstore.unity.com/packages/audio/sound-fx/free-casual-soundfx-pack-164843)

Pixel Arts:
Fantasy Wooden GUI Free by Black Hammer from the Unity Asset Store(https://assetstore.unity.com/packages/2d/gui/fantasy-wooden-gui-free-103811)

Free Pixel Food by Henry Software from the Unity Asset Store(https://assetstore.unity.com/packages/2d/environments/free-pixel-food-113523)