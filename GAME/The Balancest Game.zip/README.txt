Author: Sungmin Kang

Game: The Balancest Game

Description: The Balancest Game is the 2D platformer game. Move your character, Get some food, and back to your house. Make sure, balance your time(life) and eating foods. Some food will reduce, or increase your time. If you fail to balance your time, so when the time reduces, or increased too much, then.....?

How to Play: 
	left arrow: move left
	right arrow: move right
	space bar: jump


References:

Music - 
Leafre,Murueng,Elinia OST by MapleStory from Nexon Corporation(https://maplestory.nexon.com/Media/Music#a)

Free Casual SoundFX Pack by Tim Beek from the Unity asset Score
(https://assetstore.unity.com/packages/audio/sound-fx/free-casual-soundfx-pack-164843)

Pixel Arts:
Fantasy Wooden GUI Free by Black Hammer from the Unity Asset Store(https://assetstore.unity.com/packages/2d/gui/fantasy-wooden-gui-free-103811)

Free Pixel Food by Henry Software from the Unity Asset Store(https://assetstore.unity.com/packages/2d/environments/free-pixel-food-113523)