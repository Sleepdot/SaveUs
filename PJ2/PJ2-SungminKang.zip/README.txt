Developer: Sungmin Kang

Game Title: VE (Change to "SAVE US" when player complete the game)

Description: "VE" is the 2D platformer game. Player is dropt in the World that lost some of alphabets. Come back to your world, player has to find the lost alphabet. Unfortunately, lost alphabet limits your actions. Explore the world, find the lost alphabets, and unlock your actions to come back. In fortune, you may get some treasure.....? Time and gravity are not always your frield. Watch out the time limitation and  cliff. Jump over the cliff and run fast to reach the magical door on time.

Key: 
	left arrow: move left
	right arrow: move right
	space bar: jump
	left shift: dash

How to Play: 
	Go right until you reach to the magical door.
	Find the alphabets, contact to the alphabets and free them. 
	When you free enough alphabets to make an action keyword, you can unlock the actions to use.
	Watch out the cliff. When the player falls, game will be ended.
	When the time over, game will be ended.
	You can hold the wall when you keep your arrow buttons to the matched direction.
	Watch out the ramp. Ramp makes character slightly fly.


References:

Music - 
DragonNest, LetsMarch OST by MapleStory from Nexon Corporation(https://maplestory.nexon.com/Media/Music#a)

Free Casual SoundFX Pack by Tim Beek from the Unity asset Score
(https://assetstore.unity.com/packages/audio/sound-fx/free-casual-soundfx-pack-164843)

Pixel Arts:
Fantasy Wooden GUI Free by Black Hammer from the Unity Asset Store(https://assetstore.unity.com/packages/2d/gui/fantasy-wooden-gui-free-103811)

Free Pixel Food by Henry Software from the Unity Asset Store(https://assetstore.unity.com/packages/2d/environments/free-pixel-food-113523)

Fantasy Free GUI by ZOSMA from the Unity Asset Store(https://assetstore.unity.com/packages/2d/gui/icons/fantasy-free-gui-147682)

Futuristic Letter Models by Kaden Campbell from the Unity Asset Store(https://assetstore.unity.com/packages/3d/props/futuristic-letter-models-176110)